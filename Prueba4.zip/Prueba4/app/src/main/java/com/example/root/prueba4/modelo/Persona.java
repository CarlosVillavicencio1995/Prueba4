package com.example.root.prueba4.modelo;

import java.util.List;

public class Persona {
    private String Cedula;
    private String Nombre;
    private String Recinto;
    private String Junta;
    private String Direccion;
    private String Provincia;
    private String Canton;
    private String Parroquia;
    private String Zona;

    public Persona() {

    }

    public Persona(String cedula, String nombre, String recinto, String junta, String direccion, String provincia, String canton, String parroquia, String zona) {
        Cedula = cedula;
        Nombre = nombre;
        Recinto = recinto;
        Junta = junta;
        Direccion = direccion;
        Provincia = provincia;
        Canton = canton;
        Parroquia = parroquia;
        Zona = zona;
    }

    public String getCedula() {
        return Cedula;
    }

    public void setCedula(String cedula) {
        Cedula = cedula;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getRecinto() {
        return Recinto;
    }

    public void setRecinto(String recinto) {
        Recinto = recinto;
    }

    public String getJunta() {
        return Junta;
    }

    public void setJunta(String junta) {
        Junta = junta;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String direccion) {
        Direccion = direccion;
    }

    public String getProvincia() {
        return Provincia;
    }

    public void setProvincia(String provincia) {
        Provincia = provincia;
    }

    public String getCanton() {
        return Canton;
    }

    public void setCanton(String canton) {
        Canton = canton;
    }

    public String getParroquia() {
        return Parroquia;
    }

    public void setParroquia(String parroquia) {
        Parroquia = parroquia;
    }

    public String getZona() {
        return Zona;
    }

    public void setZona(String zona) {
        Zona = zona;
    }


}
