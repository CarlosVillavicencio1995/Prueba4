package com.example.root.prueba4.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.root.prueba4.R;
import com.example.root.prueba4.modelo.Persona;

import java.util.ArrayList;

public class PersonaAdapter extends BaseAdapter {

    private Context contexto;
    private ArrayList<Persona> listaPersonas;

    public PersonaAdapter(Context contexto, ArrayList<Persona> listaPersonas) {
        this.contexto = contexto;
        this.listaPersonas = listaPersonas;
    }

    @Override
    public int getCount() {
        return listaPersonas.size();
    }

    @Override
    public Object getItem(int position) {
        return listaPersonas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView==null)
            convertView = View.inflate(contexto, R.layout.dlg_displaypersonas, null);



        TextView cajaCedula = convertView.findViewById(R.id.lblCedula);
        TextView cajaNombre = convertView.findViewById(R.id.lblNombre);
        TextView cajaRecinto= convertView.findViewById(R.id.lblRecinto);
        TextView cajaJunta = convertView.findViewById(R.id.lblJunta);
        TextView cajaDireccion = convertView.findViewById(R.id.lblDireccion);
        TextView cajaProvincia = convertView.findViewById(R.id.lblProvincia);
        TextView cajaCanton= convertView.findViewById(R.id.lblCanton);
        TextView cajaParroquia = convertView.findViewById(R.id.lblParroquia);
        TextView cajaZona = convertView.findViewById(R.id.lblZona);


        Persona l = listaPersonas.get(position);

        cajaCedula.setText(l.getCedula());
        cajaNombre.setText(l.getNombre());
        cajaRecinto.setText(l.getRecinto());
        cajaJunta.setText(l.getJunta());
        cajaDireccion.setText(l.getDireccion());
        cajaProvincia.setText(l.getProvincia());
        cajaCanton.setText(l.getCanton());
        cajaParroquia.setText(l.getParroquia());
        cajaZona.setText(l.getZona());

        return convertView;
    }

    public Context getContexto() {
        return contexto;
    }

    public void setContexto(Context contexto) {
        this.contexto = contexto;
    }

    public ArrayList<Persona> getListaPersonas() {
        return listaPersonas;
    }

    public void setListaPersonas(ArrayList<Persona> listaPersonas) {
        this.listaPersonas = listaPersonas;
    }
}
