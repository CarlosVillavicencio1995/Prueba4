package com.example.root.prueba4;

import android.app.Dialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.root.prueba4.adapter.PersonaAdapter;
import com.example.root.prueba4.helper.PersonaHelper;
import com.example.root.prueba4.modelo.Persona;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ActividadPrincipal extends AppCompatActivity implements AdapterView.OnItemClickListener {

    Button botonCrear,botonEliminarTodos,botonBuscar;
    ListView listaView;
    PersonaHelper personaHelper;
    Persona persona;
    ArrayList<Persona> personas;
    List<Persona> listaPersona;
    PersonaAdapter personaAdapter;
    ArrayList<Persona> Items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_principal);


        personaHelper = new PersonaHelper(this, "PERSONA", null, 1);
        listaView = (ListView) findViewById(R.id.ListViewPersonas);

        mostrarLista();
        listaView.setOnItemClickListener(this);

        botonBuscar = (Button) findViewById(R.id.btnBuscar);
        botonCrear = (Button) findViewById(R.id.btnCrear);
        botonEliminarTodos = (Button) findViewById(R.id.btnEliminarTodos);


        botonEliminarTodos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                personaHelper.eliminarTodos();
                mostrarLista();

            }
        });

        botonCrear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dlgCrearPersona = new Dialog(ActividadPrincipal.this);
                dlgCrearPersona.setContentView(R.layout.dlg_crearpersonas);

                final EditText cajaCedula = (EditText) dlgCrearPersona.findViewById(R.id.txtCedula);
                final EditText cajaNombre = (EditText) dlgCrearPersona.findViewById(R.id.txtNombre);
                final EditText cajaRecinto = (EditText) dlgCrearPersona.findViewById(R.id.txtRecinto);
                final EditText cajaJunta = (EditText) dlgCrearPersona.findViewById(R.id.txtJunta);
                final EditText cajaDireccion = (EditText) dlgCrearPersona.findViewById(R.id.txtDireccion);
                final EditText cajaProvincia = (EditText) dlgCrearPersona.findViewById(R.id.txtProvincia);
                final EditText cajaCanton = (EditText) dlgCrearPersona.findViewById(R.id.txtCanton);
                final EditText cajaParroquia = (EditText) dlgCrearPersona.findViewById(R.id.txtParroquia);
                final EditText cajaZona = (EditText) dlgCrearPersona.findViewById(R.id.txtZona);

                Button btnCrear = (Button) dlgCrearPersona.findViewById(R.id.btnCrearLibro);

                btnCrear.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Persona p = new Persona();
                        p.setCedula(cajaCedula.getText().toString());
                        p.setNombre(cajaNombre.getText().toString());
                        p.setRecinto(cajaRecinto.getText().toString());
                        p.setJunta(cajaJunta.getText().toString());
                        p.setDireccion(cajaDireccion.getText().toString());
                        p.setProvincia(cajaProvincia.getText().toString());
                        p.setCanton(cajaCanton.getText().toString());
                        p.setParroquia(cajaParroquia.getText().toString());
                        p.setZona(cajaZona.getText().toString());

                        personaHelper.insertar(p);
                        mostrarLista();
                        dlgCrearPersona.hide();
                    }
                });

                dlgCrearPersona.show();
            }
        });

    }


    private void mostrarLista(){
        personas = new ArrayList<Persona>();
        //prod = new Producto();
        listaPersona = personaHelper.leerTodos();

        for (int i =0; i<listaPersona.size(); i++) {
            persona = listaPersona.get(i);
            personas.add(persona);
        }
        personaAdapter =  new PersonaAdapter(ActividadPrincipal.this, personas);
        listaView.setAdapter(personaAdapter);
        personaAdapter.notifyDataSetChanged();
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        final Dialog dialog = new Dialog(ActividadPrincipal.this);
        dialog.setContentView(R.layout.dlg_opciones);

        Items = obtenerPersonasItem();
        final TextView cajaCedula = (TextView)dialog.findViewById(R.id.txt_Cedula);
        final TextView cajaNombre = (TextView)dialog.findViewById(R.id.txt_Nombre);
        final TextView cajaRecinto = (TextView)dialog.findViewById(R.id.txt_Recinto);
        final TextView cajaJunta = (TextView)dialog.findViewById(R.id.txt_Junta);
        final TextView cajaDireccion = (TextView)dialog.findViewById(R.id.txt_Direccion);
        final TextView cajaProvincia = (TextView)dialog.findViewById(R.id.txt_Provincia);
        final TextView cajaCanton = (TextView)dialog.findViewById(R.id.txt_Canton);
        final TextView cajaParroquia = (TextView)dialog.findViewById(R.id.txt_Parroquia);
        final TextView cajaZona = (TextView)dialog.findViewById(R.id.txt_Zona);



    }


    private ArrayList<Persona> obtenerPersonasItem(){
        personas = new ArrayList<Persona>();
        //prod = new Producto();
        listaPersona = personaHelper.leerTodos();

        for (int i =0; i<listaPersona.size(); i++) {
            persona = listaPersona.get(i);
            personas.add(persona);
        }
        return personas;
    }
}
